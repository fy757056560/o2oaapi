package com.x.program.center.jaxrs.code;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

    protected static final String CUSTOM_SMS_APPLICATION = "x_sms_assemble_control";

    protected static final String CUSTOM_SMS_CONFIG_NAME = "custom_sms";

}
