package com.x.program.center;

public interface CenterQueueBody {

	public static final String TYPE_REFRESHAPPLICATION = "refreshApplication";
	public static final String TYPE_REGISTAPPLICATIONS = "registApplications";

	public abstract String type();

}
