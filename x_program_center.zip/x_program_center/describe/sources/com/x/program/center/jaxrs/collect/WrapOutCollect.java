package com.x.program.center.jaxrs.collect;

import java.util.ArrayList;
import java.util.List;

import com.x.base.core.project.config.Collect;

public class WrapOutCollect extends Collect {
	public static List<String> Excludes = new ArrayList<>();
}
