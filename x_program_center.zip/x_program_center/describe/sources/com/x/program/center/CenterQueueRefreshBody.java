package com.x.program.center;

public class CenterQueueRefreshBody implements CenterQueueBody {

	public String type() {
		return TYPE_REFRESHAPPLICATION;
	}

}
