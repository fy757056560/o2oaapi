package com.x.program.center.jaxrs.storagemappings;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

	 
}