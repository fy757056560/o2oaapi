package com.x.attendance.assemble.control;

import javax.activation.MimetypesFileTypeMap;

public class MimeTypeDefinition {
	public static MimetypesFileTypeMap instance;
}
