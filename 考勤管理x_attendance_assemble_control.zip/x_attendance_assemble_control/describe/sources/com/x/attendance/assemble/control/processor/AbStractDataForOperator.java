package com.x.attendance.assemble.control.processor;

public abstract class AbStractDataForOperator{

	protected String data_type = null;
	
	public String getData_type() {
		return data_type;
	}

	public void setData_type(String data_type) {
		this.data_type = data_type;
	}
	
}
