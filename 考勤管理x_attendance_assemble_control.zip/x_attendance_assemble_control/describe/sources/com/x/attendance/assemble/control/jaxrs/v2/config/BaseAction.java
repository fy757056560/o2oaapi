package com.x.attendance.assemble.control.jaxrs.v2.config;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

}
