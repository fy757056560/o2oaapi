package com.x.attendance.assemble.control.jaxrs.attendancedetail;

public class AttendanceCycles {
	
	private String cycleYear;
	
	private String cycleMonth;
	
	public String getCycleYear() {
		return cycleYear;
	}
	public void setCycleYear(String cycleYear) {
		this.cycleYear = cycleYear;
	}
	public String getCycleMonth() {
		return cycleMonth;
	}
	public void setCycleMonth(String cycleMonth) {
		this.cycleMonth = cycleMonth;
	}
}
