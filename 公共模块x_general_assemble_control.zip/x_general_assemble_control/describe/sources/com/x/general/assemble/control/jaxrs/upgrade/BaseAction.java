package com.x.general.assemble.control.jaxrs.upgrade;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

}
