package com.x.general.assemble.control.jaxrs.excel;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

public class BaseAction extends StandardJaxrsAction {

}
