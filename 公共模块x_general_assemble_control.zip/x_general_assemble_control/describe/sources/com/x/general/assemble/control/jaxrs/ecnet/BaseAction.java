package com.x.general.assemble.control.jaxrs.ecnet;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

}
