package com.x.organization.assemble.authentication.jaxrs.mpweixin;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

}
