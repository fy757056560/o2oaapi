package com.x.organization.assemble.personal.jaxrs.icon;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

}