package com.x.organization.assemble.personal.jaxrs.password;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class ActionBase extends StandardJaxrsAction {

}
