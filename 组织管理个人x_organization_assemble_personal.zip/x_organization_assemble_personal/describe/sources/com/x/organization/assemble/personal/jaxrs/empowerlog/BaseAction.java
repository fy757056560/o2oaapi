package com.x.organization.assemble.personal.jaxrs.empowerlog;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

}