package com.x.organization.assemble.control;

public enum MappingItemValueType {
	string, stringList, date, integer, genderType
}
